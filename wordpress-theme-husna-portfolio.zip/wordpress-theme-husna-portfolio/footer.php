<footer>
    &copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>
  </footer>
  <?php wp_footer(); ?>
</body>
</html>
